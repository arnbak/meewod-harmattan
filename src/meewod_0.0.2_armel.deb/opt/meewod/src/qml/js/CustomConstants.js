.pragma library

function func() {
    
}
